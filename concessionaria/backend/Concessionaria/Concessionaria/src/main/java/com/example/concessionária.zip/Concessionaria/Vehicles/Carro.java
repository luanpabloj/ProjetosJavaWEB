package com.example.Concessionaria.Vehicles;

import com.example.Concessionaria.Vehicles.DTO.CarroRequestDTO;
import com.example.Concessionaria.Vehicles.DTO.CarroResponseDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table(name = "carros")
@Entity(name = "carro")
@Getter
@EqualsAndHashCode(of = "id")

public class Carro extends Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String arCondicionado;
    private String vidrosEletricos;
    private Integer portas;
    private String carroceria;
    private String tracao;

    public Carro(){
        super();
    }

    public Carro(CarroRequestDTO data) {
        super(data.marca(), data.modelo(), data.ano(), data.valor(), data.quilometragem(),
                data.combustivel(), data.transmissao(), data.motor(), data.cor(), data.condicao(),
                data.imagem());
        this.arCondicionado = data.arCondicionado();
        this.vidrosEletricos = data.vidrosEletricos();
        this.portas = data.portas();
        this.carroceria = data.carroceria();
        this.tracao = data.tracao();
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getArCondicionado() {
        return arCondicionado;
    }

    public void setArCondicionado(String arCondicionado) {
        this.arCondicionado = arCondicionado;
    }

    public String getVidrosEletricos() {
        return vidrosEletricos;
    }

    public void setVidrosEletricos(String vidrosEletricos) {
        this.vidrosEletricos = vidrosEletricos;
    }

    public Integer getPortas() {
        return portas;
    }

    public void setPortas(Integer portas) {
        this.portas = portas;
    }

    public String getCarroceria() {
        return carroceria;
    }

    public void setCarroceria(String carroceria) {
        this.carroceria = carroceria;
    }

    public String getTracao() {
        return tracao;
    }

    public void setTracao(String tracao) {
        this.tracao = tracao;
    }
}

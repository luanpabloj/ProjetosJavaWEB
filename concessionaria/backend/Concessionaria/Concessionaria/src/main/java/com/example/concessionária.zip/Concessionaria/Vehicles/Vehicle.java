package com.example.Concessionaria.Vehicles;

import com.example.Concessionaria.Vehicles.DTO.CarroRequestDTO;

public abstract class Vehicle {

    protected String marca;
    protected String modelo;
    protected int ano;
    protected Double valor;
    protected Double quilometragem;
    protected String combustivel;
    protected String transmissao;
    protected String motor;
    protected String cor;
    protected String condicao;
    protected String imagem;

    public Vehicle(){

    }

    public Vehicle(String marca, String modelo, int ano, Double valor, Double quilometragem, String combustivel, String transmissao, String motor, String cor, String condicao, String imagem) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.valor = valor;
        this.quilometragem = quilometragem;
        this.combustivel = combustivel;
        this.transmissao = transmissao;
        this.motor = motor;
        this.cor = cor;
        this.condicao = condicao;
        this.imagem = imagem;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getQuilometragem() {
        return quilometragem;
    }

    public void setQuilometragem(Double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public String getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }

    public String getTransmissao() {
        return transmissao;
    }

    public void setTransmissao(String transmissao) {
        this.transmissao = transmissao;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getCondicao() {
        return condicao;
    }

    public void setCondicao(String condicao) {
        this.condicao = condicao;
    }
}

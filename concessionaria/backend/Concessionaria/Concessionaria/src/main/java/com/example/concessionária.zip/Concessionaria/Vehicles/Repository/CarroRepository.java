package com.example.Concessionaria.Vehicles.Repository;

import com.example.Concessionaria.Vehicles.Carro;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CarroRepository extends JpaRepository<Carro, Long>{
}
